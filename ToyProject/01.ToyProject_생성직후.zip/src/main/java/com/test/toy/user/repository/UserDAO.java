package com.test.toy.user.repository;

public class UserDAO {

}
